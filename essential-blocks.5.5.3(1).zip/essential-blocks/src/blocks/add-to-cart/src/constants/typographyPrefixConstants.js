export const btnTypo = "btnTypo";
export const quantityTypo = "quantityTypo";
export const variableLabelTypo = "variableLabelTypo";
export const variableFieldTypo = "variableFieldTypo";
export const groupedNameTypo = "groupedNameTypo";
export const regularPriceTypo = "regularPriceTypo";
export const salePriceTypo = "salePriceTypo";
