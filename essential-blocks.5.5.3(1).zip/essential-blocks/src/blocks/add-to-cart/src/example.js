const Example = {
    attributes: {},
};
export default Example;