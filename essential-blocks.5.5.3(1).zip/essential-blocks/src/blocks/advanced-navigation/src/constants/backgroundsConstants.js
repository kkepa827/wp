// each and every const here has to be totally unique from one another
export const prefixWrapBg = "wrpBg_";
export const prefixNavBg = "navBg_";
export const prefixActNavBg = "actNavBg_";
export const prefixContentBg = "conBg_";
export const prefixTtlWrpBg = "ttlWBg_";
