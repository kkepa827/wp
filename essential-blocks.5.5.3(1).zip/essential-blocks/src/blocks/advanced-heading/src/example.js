const Example = {
	attributes: {
		displaySubtitle: true,
		displaySeperator: true,
		align: "left",
		titleColor: "#551ef7",
		subtitleColor: "#555555",
		separatorColor: "#551ef7",
		seperatorType: "line",
		wrpPaddingisLinked: false,
		wrpPaddingUnit: "px",
		wrpPaddingTop: "0",
		wrpPaddingBottom: "0",
		wrpPaddingLeft: "0",
		wrpPaddingRight: "0",
		wrprBgbackgroundColor: "rgba(255,255,255,1)",
		wrprBgbackgroundType: "classic",
	}
};
export default Example;