// each and every const here has to be totally unique from one another

export const wrapMarginConst = "wrpMrg_";
export const wrapPaddingConst = "wrpPad_";
export const iconMarginConst = "icnMrg_";
export const iconPaddingConst = "icnPad_";
export const tabMarginConst = "tabMrg_";
export const tabPaddingConst = "tabPad_";
export const conMarginConst = "conMrg_";
export const conPaddingConst = "conPad_";
export const imgContainerPadding = "imgContainerPadding";
export const imgContainerMargin = "imgContainerMargin";
export const accordionMargin = "accordionMargin";
export const accordionPadding = "accordionPadding";
export const titlePrefixPadding = "titlePrefixPadding";
export const titleSuffixPadding = "titleSuffixPadding";
export const titlePrefixMargin = "titlePrefixMargin";
export const titleSuffixMargin = "titleSuffixMargin";
