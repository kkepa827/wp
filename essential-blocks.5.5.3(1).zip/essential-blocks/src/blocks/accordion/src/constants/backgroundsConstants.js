// each and every const here has to be totally unique from one another

export const WrpBgConst = "WrpBg_";
export const iconBgConst = "icnBg_";
export const tabBgConst = "tabBg_";
export const conBgConst = "conBg_";
export const accordionBackground = "accordionBackground";
export const accordionExpandedBackground = "accordionExpandedBackground";
export const titlePrefixBG = "titlePrefixBG";
export const titleSuffixBG = "titleSuffixBG";
