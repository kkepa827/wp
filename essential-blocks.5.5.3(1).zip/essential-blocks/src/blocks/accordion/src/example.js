const example = {
	attributes: {
		accordions: [
			{
				title: "Accordion Tab Title 1",
				content:
					"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
			},
			{
				title: "Accordion Tab Title 2",
				content:
					"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
			}
		],
		displayIcon: true,
		tabIcon: "fas fa-angle-right"
	}
};

export default example;
