const EBSaveConfirm = (props) => {
	return (
		<div className="eb-settings-loader">
			<div className="eb-setting-saved">
				<span>Saved</span>
			</div>
		</div>
	);
};

export default EBSaveConfirm;
