export { default as TabGeneral } from "./TabGeneral";
export { default as Blocks } from "./TabBlocks";
export { default as TabTemplates } from "./TabTemplates";
export { default as TabOptions } from "./TabOptions";
export { default as TabIntegrations } from "./TabIntegrations";
export { default as TabWriteAi } from "./TabWriteAi";
