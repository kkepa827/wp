<?php return array('dependencies' => array('react', 'wp-dom-ready', 'wp-element'), 'version' => '4430ea4b4d8ef76c423b');
