<?php return array('dependencies' => array(), 'version' => '482b264a34a69dcf0a85');
