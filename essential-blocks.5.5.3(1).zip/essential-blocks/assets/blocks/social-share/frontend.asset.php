<?php return array('dependencies' => array(), 'version' => '008d6714c3ef7b5b74e9');
