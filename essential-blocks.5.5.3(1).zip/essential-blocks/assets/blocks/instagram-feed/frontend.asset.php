<?php return array('dependencies' => array(), 'version' => '06f68e70937accf68dd1');
