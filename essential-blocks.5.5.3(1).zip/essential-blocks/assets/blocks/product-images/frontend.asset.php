<?php return array('dependencies' => array('wp-dom-ready'), 'version' => 'd4e47c6fec4fc91a5745');
