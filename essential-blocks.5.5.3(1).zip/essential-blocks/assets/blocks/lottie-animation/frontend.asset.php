<?php return array('dependencies' => array(), 'version' => '1f6fc17b51cd67adb518');
