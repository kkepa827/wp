<?php return array('dependencies' => array(), 'version' => 'c4bfba143fb7cd86c0f7');
