<?php return array('dependencies' => array(), 'version' => 'efa9cca9e515558a2bcc');
