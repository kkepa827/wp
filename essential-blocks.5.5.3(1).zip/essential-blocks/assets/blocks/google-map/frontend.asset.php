<?php return array('dependencies' => array('wp-i18n'), 'version' => '3b3945fa43385c78b630');
