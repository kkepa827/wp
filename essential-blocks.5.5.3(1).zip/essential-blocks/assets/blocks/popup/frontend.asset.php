<?php return array('dependencies' => array(), 'version' => 'e2b51174c738fd9d40bd');
