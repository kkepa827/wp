<?php return array('dependencies' => array('wp-dom-ready'), 'version' => 'dee988cedd8765e14aeb');
