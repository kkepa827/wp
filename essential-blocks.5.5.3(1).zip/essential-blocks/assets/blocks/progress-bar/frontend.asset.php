<?php return array('dependencies' => array('wp-dom-ready'), 'version' => 'b6874d679aee093e7d48');
