<?php return array('dependencies' => array('react', 'wp-element'), 'version' => 'd2fbbfb7f879aeb7aba9');
