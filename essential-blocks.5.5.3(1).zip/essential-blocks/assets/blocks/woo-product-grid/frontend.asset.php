<?php return array('dependencies' => array('wp-api-fetch'), 'version' => '372f14043e1e2e424791');
