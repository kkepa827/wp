<?php return array('dependencies' => array(), 'version' => '54e4b7978873aa7310c4');
