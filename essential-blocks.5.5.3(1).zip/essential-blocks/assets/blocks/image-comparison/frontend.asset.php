<?php return array('dependencies' => array('react', 'wp-element'), 'version' => '1aab822687304b011c4c');
