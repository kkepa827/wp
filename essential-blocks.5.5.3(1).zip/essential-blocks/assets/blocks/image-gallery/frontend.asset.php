<?php return array('dependencies' => array(), 'version' => '15031e7bf88d526646ec');
