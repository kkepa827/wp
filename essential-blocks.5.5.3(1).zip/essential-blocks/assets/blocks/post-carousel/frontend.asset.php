<?php return array('dependencies' => array('wp-api-fetch'), 'version' => '411e520c006d798e020f');
