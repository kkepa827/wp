<?php return array('dependencies' => array(), 'version' => '8688e4ffaa01be3fde15');
