<?php return array('dependencies' => array(), 'version' => '73aca974af2d012b63e9');
