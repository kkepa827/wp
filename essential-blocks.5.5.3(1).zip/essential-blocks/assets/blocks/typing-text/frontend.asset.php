<?php return array('dependencies' => array(), 'version' => 'bee81f069f467ca12ee6');
