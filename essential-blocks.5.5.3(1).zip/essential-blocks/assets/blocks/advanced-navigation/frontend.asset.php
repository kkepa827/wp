<?php return array('dependencies' => array(), 'version' => '33be25d7d7cae261c527');
