<?php return array('dependencies' => array('wp-api-fetch'), 'version' => '8732e85f1dd288a22034');
