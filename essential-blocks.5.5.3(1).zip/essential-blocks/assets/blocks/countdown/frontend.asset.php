<?php return array('dependencies' => array('wp-dom-ready'), 'version' => 'd4ba21ff2cd673d256ff');
