<?php return array('dependencies' => array(), 'version' => '3d36d5b7cef770637ba5');
