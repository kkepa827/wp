<?php return array('dependencies' => array(), 'version' => 'f68cf733e3982c10ca56');
