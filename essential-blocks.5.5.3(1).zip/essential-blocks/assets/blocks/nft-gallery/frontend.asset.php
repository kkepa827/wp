<?php return array('dependencies' => array('lodash', 'react', 'wp-element'), 'version' => 'f909a53d2afab125af0b');
