<?php return array('dependencies' => array(), 'version' => '14130cf2028df4ae0677');
