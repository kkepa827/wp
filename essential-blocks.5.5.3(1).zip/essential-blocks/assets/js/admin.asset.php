<?php return array('dependencies' => array(), 'version' => '85bf6f1211814f30f872');
