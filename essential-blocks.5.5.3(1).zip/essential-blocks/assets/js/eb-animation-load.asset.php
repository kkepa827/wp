<?php return array('dependencies' => array(), 'version' => 'e18fb7d2aff07a573908');
