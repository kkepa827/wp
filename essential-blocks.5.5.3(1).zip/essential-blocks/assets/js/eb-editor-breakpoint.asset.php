<?php return array('dependencies' => array(), 'version' => 'db844bc4056dc779b2dd');
