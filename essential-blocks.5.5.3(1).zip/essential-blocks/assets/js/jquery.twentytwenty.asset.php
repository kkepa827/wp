<?php return array('dependencies' => array(), 'version' => '603b6003ae935a75551d');
