<?php return array('dependencies' => array(), 'version' => '31d6cfe0d16ae931b73c');
