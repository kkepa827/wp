<?php return array('dependencies' => array(), 'version' => 'e2e3d7e28e9f8031ea35');
