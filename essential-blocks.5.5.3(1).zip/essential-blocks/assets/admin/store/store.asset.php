<?php return array('dependencies' => array('wp-data', 'wp-polyfill'), 'version' => '78a3ee33a739fba6397a');
